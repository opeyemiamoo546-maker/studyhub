import { Canvas, useFrame } from '@react-three/fiber';
import { useRef } from 'react';
import { Mesh } from 'three';
import { RoundedBox, Float, Environment } from '@react-three/drei';

function Book() {
  const meshRef = useRef<Mesh>(null);
  
  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y = state.clock.getElapsedTime() * 0.5;
    }
  });

  return (
    <Float speed={2} rotationIntensity={1} floatIntensity={1}>
      <mesh ref={meshRef}>
        <RoundedBox args={[2, 3, 0.5]} radius={0.1} smoothness={4}>
          <meshStandardMaterial color="#5d4037" />
        </RoundedBox>
        <mesh position={[0, 0, 0.26]}>
          <boxGeometry args={[1.5, 2.5, 0.01]} />
          <meshStandardMaterial color="#efebe9" />
        </mesh>
      </mesh>
    </Float>
  );
}

export default function Hero3D() {
  return (
    <div className="w-full h-64 cursor-grab active:cursor-grabbing">
      <Canvas camera={{ position: [0, 0, 5], fov: 50 }}>
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} intensity={1} />
        <spotLight position={[-10, 10, 10]} angle={0.15} penumbra={1} />
        <Book />
        <Environment preset="city" />
      </Canvas>
    </div>
  );
}
