import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { 
  LayoutDashboard, 
  ShieldCheck, 
  Users, 
  Settings,
  Calculator,
  BrainCircuit,
  GraduationCap,
  Shield
} from 'lucide-react';

interface SidebarProps {
  onClose?: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ onClose }) => {
  const { isAdmin } = useAuth();

  const menuItems = [
    { icon: LayoutDashboard, label: 'Dashboard', path: '/' },
    { icon: BrainCircuit, label: 'AI Tutor', path: '/ai-tutor', hideForAdmin: true },
    { icon: ShieldCheck, label: 'File Vault', path: '/file-vault' },
    { icon: Users, label: 'Peer Chat', path: '/peer-chat', hideForAdmin: true },
    { icon: Users, label: 'Student Chat', path: '/admin-chat', showOnlyForAdmin: true },
    { icon: Calculator, label: 'Tools', path: '/tools' },
    { icon: Shield, label: 'Admin Panel', path: '/admin', showOnlyForAdmin: true },
  ];

  const filteredItems = menuItems.filter(item => {
    if (item.hideForAdmin && isAdmin) return false;
    if (item.showOnlyForAdmin && !isAdmin) return false;
    return true;
  });

  return (
    <div className="w-64 h-full bg-[#5d4037] text-stone-100 flex flex-col transition-all duration-300">
      <div className="p-6 border-b border-[#8d6e63]">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-3">
            <div className="bg-white p-2 rounded-xl shadow-md">
              <GraduationCap className="text-[#5d4037]" size={32} />
            </div>
            <div>
              <h1 className="font-extrabold text-2xl tracking-tight leading-none">EDU</h1>
              <p className="text-[10px] uppercase tracking-widest opacity-70">Vault</p>
            </div>
          </div>
        </div>

        <nav className="space-y-2">
          {filteredItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              onClick={onClose}
              className={({ isActive }) =>
                `flex items-center space-x-3 p-3 rounded-xl transition-all duration-200 group ${
                  isActive 
                    ? 'bg-[#8d6e63] text-white shadow-lg shadow-black/20' 
                    : 'hover:bg-[#8d6e63]/50 text-stone-300 hover:text-white'
                }`
              }
            >
              <item.icon size={22} className="group-hover:scale-110 transition-transform" />
              <span className="font-medium">{item.label}</span>
            </NavLink>
          ))}
        </nav>
      </div>

      <div className="mt-auto p-6">
        <button className="flex items-center space-x-3 p-3 w-full rounded-xl hover:bg-[#8d6e63]/50 text-stone-300 hover:text-white transition-all duration-200 group">
          <Settings size={22} className="group-hover:rotate-45 transition-transform duration-500" />
          <span className="font-medium">Settings</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
