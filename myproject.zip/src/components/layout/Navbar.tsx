import React, { useState, useEffect } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { LogOut, Bell, Menu, X } from 'lucide-react';
import toast from 'react-hot-toast';

interface NavbarProps {
  onMenuToggle: () => void;
  isMenuOpen: boolean;
}

const Navbar: React.FC<NavbarProps> = ({ onMenuToggle, isMenuOpen }) => {
  const { user, logout, messages } = useAuth();
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [prevMessageCount, setPrevMessageCount] = useState(0);

  useEffect(() => {
    // Initial load of notifications
    const welcomeNote = { id: Date.now(), title: 'Welcome to EduVault', description: 'Explore the AI Tutor and secure your files!', time: 'Just now', read: false };
    setNotifications([welcomeNote]);
    setPrevMessageCount(messages.length);
  }, [user?.id]);

  useEffect(() => {
    const handleMessageUpdate = () => {
      const allMsgs = JSON.parse(localStorage.getItem('global_messages') || '[]');
      
      // Check if we have new messages
      if (allMsgs.length > prevMessageCount) {
        const newMsgs = allMsgs.slice(prevMessageCount);
        const forMe = newMsgs.filter((m: any) => m.receiverId === user?.id && m.senderId !== user?.id);
        
        if (forMe.length > 0) {
          const newNotifs = forMe.map((m: any) => ({
            id: m.id,
            title: m.isAdminMsg ? '⚠️ Official Admin Message' : `💬 From: ${m.senderName}`,
            description: m.content,
            time: 'Just now',
            read: false,
            isAdmin: m.isAdminMsg
          }));

          setNotifications(prev => [...newNotifs, ...prev]);

          forMe.forEach((m: any) => {
            if (m.isAdminMsg) {
              toast.custom((t) => (
                <div className={`${t.visible ? 'animate-enter' : 'animate-leave'} max-w-md w-full bg-stone-900 shadow-2xl rounded-2xl pointer-events-auto flex ring-1 ring-black ring-opacity-5 border-l-4 border-amber-500`}>
                  <div className="flex-1 w-0 p-4">
                    <div className="flex items-start">
                      <div className="flex-shrink-0 pt-0.5">
                        <div className="h-10 w-10 rounded-full bg-amber-500 flex items-center justify-center text-stone-900 font-bold">A</div>
                      </div>
                      <div className="ml-3 flex-1">
                        <p className="text-sm font-bold text-white uppercase tracking-widest">System Notification</p>
                        <p className="mt-1 text-sm text-stone-300">{m.content}</p>
                      </div>
                    </div>
                  </div>
                  <div className="flex border-l border-stone-800">
                    <button onClick={() => toast.dismiss(t.id)} className="w-full border border-transparent rounded-none rounded-r-lg p-4 flex items-center justify-center text-xs font-bold text-amber-500 hover:text-amber-400 focus:outline-none">Close</button>
                  </div>
                </div>
              ), { duration: 8000, id: m.id });
            } else {
              toast(`New message from ${m.senderName}`, { icon: '💬', id: m.id });
            }
          });
        }
      }
      setPrevMessageCount(allMsgs.length);
    };

    window.addEventListener('storage_messages_updated', handleMessageUpdate);
    // Poll more frequently for that "real-time" feel
    const poll = setInterval(handleMessageUpdate, 1500);

    return () => {
      window.removeEventListener('storage_messages_updated', handleMessageUpdate);
      clearInterval(poll);
    };
  }, [user?.id, prevMessageCount]);

  return (
    <nav className="h-16 glass-morphism border-b border-stone-200 px-4 md:px-6 flex items-center justify-between sticky top-0 z-30 shadow-sm">
      <div className="flex items-center space-x-4">
        <button 
          onClick={onMenuToggle}
          className="p-2 md:hidden hover:bg-stone-100 rounded-lg transition-colors"
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
        <h2 className="text-lg md:text-xl font-bold bg-gradient-to-r from-stone-800 to-stone-500 bg-clip-text text-transparent truncate max-w-[150px] md:max-w-none">
          Student Support Hub
        </h2>
      </div>

      <div className="flex items-center space-x-4">
        <div className="relative">
          <button 
            onClick={() => setShowNotifications(!showNotifications)}
            className="p-2 hover:bg-stone-100 rounded-full transition-colors relative"
          >
            <Bell size={20} className="text-stone-600" />
            {notifications.length > 0 && (
              <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-red-500 rounded-full text-[10px] text-white flex items-center justify-center font-bold">
                {notifications.length}
              </span>
            )}
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-xl border border-stone-200 overflow-hidden z-50">
              <div className="p-4 bg-stone-50 border-b border-stone-100 font-bold text-stone-800 flex justify-between items-center">
                <span>Notifications</span>
                <button onClick={() => setNotifications([])} className="text-[10px] text-[#5d4037] hover:underline">Clear All</button>
              </div>
              <div className="max-h-64 overflow-y-auto">
                {notifications.length === 0 ? (
                  <div className="p-8 text-center text-stone-400 text-sm">No new notifications</div>
                ) : (
                  notifications.map(n => (
                    <div key={n.id} className="p-4 border-b border-stone-50 hover:bg-stone-50 transition-colors cursor-pointer">
                      <p className="text-sm font-bold text-stone-800">{n.title}</p>
                      <p className="text-xs text-stone-500">{n.description}</p>
                      <p className="text-[10px] text-stone-400 mt-1">{n.time}</p>
                    </div>
                  ))
                )}
              </div>
              <button className="w-full py-2 text-xs font-bold text-[#5d4037] hover:bg-stone-50">View All</button>
            </div>
          )}
        </div>
        
        <div className="flex items-center space-x-3 bg-stone-100 px-3 py-1.5 rounded-full border border-stone-200">
          <div className="w-8 h-8 rounded-full bg-[#5d4037] flex items-center justify-center text-white font-bold text-sm shadow-inner">
            {user?.username.charAt(0).toUpperCase()}
          </div>
          <div className="hidden md:block">
            <p className="text-sm font-semibold text-stone-800 leading-tight">{user?.username}</p>
            <p className="text-[10px] text-stone-500 leading-tight">ID: {user?.id}</p>
          </div>
          <button 
            onClick={logout}
            className="ml-2 p-1 hover:text-red-500 transition-colors"
            title="Logout"
          >
            <LogOut size={16} />
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
