import React from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '../hooks/useAuth';
import { Users, Shield, Mail, Calendar, UserPlus, Search, Filter, Hash, Fingerprint } from 'lucide-react';

const Admin: React.FC = () => {
  const { users } = useAuth();

  return (
    <div className="space-y-8 p-4 md:p-0">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-stone-900 rounded-2xl flex items-center justify-center text-white shadow-xl">
            <Shield size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-extrabold text-stone-800 tracking-tight">System Control</h1>
            <p className="text-sm text-stone-500 font-medium">Monitoring {users.length} active platform users</p>
          </div>
        </div>
        
        <div className="flex flex-col sm:flex-row items-center gap-3 w-full lg:w-auto">
           <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
            <input 
              type="text" 
              placeholder="Search by ID or Name..." 
              className="w-full pl-10 pr-4 py-2.5 bg-white border border-stone-200 rounded-xl focus:ring-2 focus:ring-stone-800 outline-none shadow-sm"
            />
          </div>
          <button className="w-full sm:w-auto bg-stone-800 text-white px-6 py-2.5 rounded-xl flex items-center justify-center gap-2 hover:bg-stone-900 transition-all shadow-md active:scale-95">
            <UserPlus size={18} /> Invite Student
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { label: 'Platform Users', value: users.length, icon: Users, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: 'Student Accounts', value: users.filter(u => u.role === 'student').length, icon: Hash, color: 'text-green-600', bg: 'bg-green-50' },
          { label: 'Admin Access', value: users.filter(u => u.role === 'admin').length, icon: Shield, color: 'text-purple-600', bg: 'bg-purple-50' },
        ].map((stat, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm hover:shadow-md transition-all group"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`w-12 h-12 ${stat.bg} ${stat.color} rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform`}>
                <stat.icon size={24} />
              </div>
              <span className="text-xs font-bold text-stone-400 uppercase tracking-widest">Real-time</span>
            </div>
            <h3 className="text-3xl font-bold text-stone-800">{stat.value}</h3>
            <p className="text-stone-500 text-sm font-semibold mt-1">{stat.label}</p>
          </motion.div>
        ))}
      </div>

      <div className="bg-white rounded-3xl shadow-sm border border-stone-200 overflow-hidden">
        <div className="p-6 border-b border-stone-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-stone-50/30">
          <div className="flex items-center gap-2">
            <Fingerprint className="text-stone-400" size={20} />
            <h3 className="font-bold text-stone-800">User Registry</h3>
          </div>
          <div className="flex items-center gap-2">
            <button className="px-3 py-1.5 bg-white border border-stone-200 rounded-lg text-stone-600 hover:text-stone-800 flex items-center gap-1.5 text-xs font-bold shadow-sm transition-all">
              <Filter size={14} /> Sort By
            </button>
            <button className="px-3 py-1.5 bg-white border border-stone-200 rounded-lg text-stone-600 hover:text-stone-800 flex items-center gap-1.5 text-xs font-bold shadow-sm transition-all">
              Export CSV
            </button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left min-w-[800px]">
            <thead>
              <tr className="border-b border-stone-100 bg-stone-50/50">
                <th className="px-6 py-5 text-xs font-extrabold text-stone-400 uppercase tracking-widest">User ID</th>
                <th className="px-6 py-5 text-xs font-extrabold text-stone-400 uppercase tracking-widest">Username</th>
                <th className="px-6 py-5 text-xs font-extrabold text-stone-400 uppercase tracking-widest">Email Address</th>
                <th className="px-6 py-5 text-xs font-extrabold text-stone-400 uppercase tracking-widest">Permission</th>
                <th className="px-6 py-5 text-xs font-extrabold text-stone-400 uppercase tracking-widest">Registry Date</th>
                <th className="px-6 py-5 text-xs font-extrabold text-stone-400 uppercase tracking-widest">Activity</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {users.map((user, idx) => (
                <motion.tr 
                  key={user.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className="hover:bg-stone-50/80 transition-colors group cursor-default"
                >
                  <td className="px-6 py-4">
                    <span className="font-mono text-xs font-bold text-stone-400 bg-stone-100 px-2 py-1 rounded-md group-hover:bg-white transition-colors">
                      {user.id}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-stone-100 border border-stone-200 flex items-center justify-center font-bold text-stone-600 shadow-inner group-hover:bg-stone-800 group-hover:text-white transition-all">
                        {user.username.charAt(0).toUpperCase()}
                      </div>
                      <span className="font-bold text-stone-800">{user.username}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-stone-600 font-medium">
                    <div className="flex items-center gap-2">
                      <Mail size={14} className="text-stone-300" />
                      {user.email}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold tracking-wider ${
                      user.role === 'admin' 
                        ? 'bg-purple-100 text-purple-700 border border-purple-200' 
                        : 'bg-blue-100 text-blue-700 border border-blue-200'
                    }`}>
                      {user.role.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-stone-500 font-medium">
                    <div className="flex items-center gap-2 text-sm">
                      <Calendar size={14} className="text-stone-300" />
                      {new Date(user.createdAt).toLocaleDateString()}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(34,197,94,0.6)]"></div>
                      <span className="text-xs font-bold text-green-600 uppercase tracking-tighter">Live Now</span>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="p-6 border-t border-stone-100 bg-stone-50/20 text-center">
          <p className="text-xs text-stone-400 font-medium">Total registered entities: {users.length} • Security Protocol v4.2.1</p>
        </div>
      </div>
    </div>
  );
};

export default Admin;
