import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { motion } from 'framer-motion';
import { GraduationCap, LogIn, Mail, Lock } from 'lucide-react';
import toast from 'react-hot-toast';

const Login: React.FC = () => {
  const [username, setUsername] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim()) {
      login(username);
      toast.success(`Welcome back, ${username}!`);
      navigate('/');
    } else {
      toast.error('Please enter a username');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center school-pattern bg-[#efebe9] p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden border border-stone-200">
          <div className="brown-gradient p-10 text-white text-center">
            <motion.div 
              initial={{ y: -20 }}
              animate={{ y: 0 }}
              className="inline-block bg-white/20 p-4 rounded-2xl backdrop-blur-md mb-4"
            >
              <GraduationCap size={48} />
            </motion.div>
            <h1 className="text-3xl font-extrabold tracking-tight">EDU VAULT</h1>
            <p className="text-stone-300">Your Secure Learning Sanctuary</p>
          </div>

          <div className="p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-stone-700 block">Username</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" size={20} />
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-[#5d4037] focus:border-transparent outline-none transition-all"
                    placeholder="Enter your student ID or name"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-stone-700 block">Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" size={20} />
                  <input
                    type="password"
                    defaultValue="password"
                    className="w-full pl-10 pr-4 py-3 bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-[#5d4037] focus:border-transparent outline-none transition-all"
                    placeholder="••••••••"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between text-sm">
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input type="checkbox" className="rounded border-stone-300 text-[#5d4037] focus:ring-[#5d4037]" />
                  <span className="text-stone-600">Remember me</span>
                </label>
                <a href="#" className="text-[#5d4037] font-semibold hover:underline">Forgot password?</a>
              </div>

              <button
                type="submit"
                className="w-full brown-btn py-4 text-lg font-bold flex items-center justify-center gap-2"
              >
                <LogIn size={20} />
                Sign In
              </button>
            </form>

            <div className="mt-8 text-center">
              <p className="text-stone-500">
                Don't have an account?{' '}
                <Link to="/register" className="text-[#5d4037] font-bold hover:underline">Register now</Link>
              </p>
            </div>
          </div>
        </div>
        
        <p className="text-center mt-6 text-stone-400 text-sm">
          &copy; 2024 EduVault Student Support System. All rights reserved.
        </p>
      </motion.div>
    </div>
  );
};

export default Login;
