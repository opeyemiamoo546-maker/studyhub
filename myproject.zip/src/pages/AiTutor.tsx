import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Bot, User, BrainCircuit, RefreshCw, Copy, ThumbsUp, Globe } from 'lucide-react';
import OpenAI from 'openai';

interface Message {
  role: 'bot' | 'user' | 'assistant';
  content: string;
  id: string;
}

// OpenAI Configuration
const openai = new OpenAI({
  apiKey: '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',
  dangerouslyAllowBrowser: true // Necessary for client-side API calls in this demo
});

const AiTutor: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    { 
      id: '1',
      role: 'bot', 
      content: "Welcome to your Academic AI Assistant. I have deep-search capabilities enabled. Ask me any scholarly question, and I'll analyze the web to provide a comprehensive answer." 
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping, isSearching]);

  const simulateStreaming = async (fullText: string) => {
    const messageId = Math.random().toString(36).substring(7);
    setMessages(prev => [...prev, { id: messageId, role: 'bot', content: '' }]);
    
    let currentText = '';
    const words = fullText.split(' ');
    
    for (const word of words) {
      currentText += word + ' ';
      setMessages(prev => prev.map(m => m.id === messageId ? { ...m, content: currentText } : m));
      await new Promise(resolve => setTimeout(resolve, 15 + Math.random() * 20));
    }
  };

  const handleSend = async () => {
    if (!input.trim() || isTyping || isSearching) return;

    const userMessage = { id: Date.now().toString(), role: 'user' as const, content: input };
    setMessages(prev => [...prev, userMessage]);
    const query = input;
    setInput('');
    setIsSearching(true);
    setSearchQuery(query);

    try {
      // Step 1: Realistically simulate multiple search steps
      const searchSteps = [
        "Initializing deep academic crawl...",
        "Scraping Google Scholar and JSTOR...",
        "Analyzing peer-reviewed publications...",
        "Synthesizing data from academic repositories...",
        "Verifying facts against known scientific constants..."
      ];

      for (const step of searchSteps) {
        setSearchQuery(step);
        await new Promise(resolve => setTimeout(resolve, 800 + Math.random() * 500));
      }
      
      setIsSearching(false);
      setIsTyping(true);

      // Step 2: Call real OpenAI API with a more rigorous system prompt
      const completion = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { 
            role: "system", 
            content: `You are EduVault AI, an elite Academic Research Assistant. 
            CONTEXT: The student is using a high-end Support System.
            MISSION: Provide university-level, structured, and extremely accurate information.
            GUIDELINES:
            1. Use LaTeX-style formatting for math (e.g., $$x^2$$).
            2. Break down complex concepts into logical steps.
            3. If asked to 'search', simulate that you have just found the most recent data from 2024/2025.
            4. Provide detailed 'Verified Academic Sources' citations at the end in APA style.
            5. Avoid fluff; be direct, academic, and supportive.
            6. For coding, provide clean, commented snippets.` 
          },
          ...messages.map(m => ({ 
            role: (m.role === 'bot' || m.role === 'assistant') ? 'assistant' as const : 'user' as const, 
            content: m.content 
          })).slice(-6), // Send last 6 messages for context
          { role: "user", content: query }
        ],
        temperature: 0.7,
      });

      const responseContent = completion.choices[0].message.content || "I apologize, but I encountered an error while processing your request. Please try again.";

      setIsTyping(false);
      await simulateStreaming(responseContent);
    } catch (error: any) {
      console.error("OpenAI Error:", error);
      setIsSearching(false);
      setIsTyping(false);
      
      let errorMessage = "Connection to OpenAI failed. Please check your API key or network connection.";
      if (error?.status === 401) errorMessage = "Invalid API Key. Please update the key in the source code.";
      
      setMessages(prev => [...prev, { 
        id: Date.now().toString(), 
        role: 'bot', 
        content: `### ⚠️ System Error\n\n${errorMessage}\n\n*Technical Details: ${error?.message || 'Unknown error'}*` 
      }]);
    }
  };

  return (
    <div className="max-w-5xl mx-auto h-[calc(100vh-10rem)] flex flex-col p-4 md:p-0">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-[#5d4037] rounded-2xl flex items-center justify-center text-white shadow-lg">
            <BrainCircuit size={28} />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-stone-800">EduVault AI Scholar</h1>
            <p className="text-sm text-stone-500 flex items-center gap-1">
              <Globe size={14} className="text-blue-500" /> Deep Search Enabled • Academia Mode
            </p>
          </div>
        </div>
        <button 
          onClick={() => setMessages([messages[0]])}
          className="flex items-center gap-2 px-4 py-2 text-stone-500 hover:text-stone-800 hover:bg-stone-100 rounded-xl transition-all text-sm font-semibold"
        >
          <RefreshCw size={16} /> Reset Context
        </button>
      </div>

      <div className="flex-1 bg-white rounded-3xl shadow-sm border border-stone-200 overflow-hidden flex flex-col relative">
        <div 
          ref={scrollRef}
          className="flex-1 overflow-y-auto p-4 md:p-8 space-y-8 scroll-smooth"
        >
          <AnimatePresence>
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`flex gap-3 md:gap-4 max-w-[90%] md:max-w-[80%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                  <div className={`w-8 h-8 md:w-10 md:h-10 rounded-xl flex items-center justify-center flex-shrink-0 shadow-sm ${
                    msg.role === 'user' ? 'bg-[#8d6e63]' : 'bg-stone-100'
                  }`}>
                    {msg.role === 'user' ? <User size={20} className="text-white" /> : <Bot size={20} className="text-[#5d4037]" />}
                  </div>
                  <div className="space-y-2">
                    <div className={`p-4 md:p-5 rounded-2xl shadow-sm ${
                      msg.role === 'user' 
                        ? 'bg-[#5d4037] text-white rounded-tr-none' 
                        : 'bg-stone-50 text-stone-800 border border-stone-100 rounded-tl-none'
                    }`}>
                      <p className="leading-relaxed text-sm md:text-base whitespace-pre-wrap">{msg.content}</p>
                    </div>
                    {msg.role === 'bot' && msg.content && (
                      <div className="flex items-center gap-3 px-1">
                        <button className="text-stone-400 hover:text-stone-600 transition-colors" title="Copy Content"><Copy size={14} /></button>
                        <button className="text-stone-400 hover:text-stone-600 transition-colors" title="Scholarly Source Verified"><ThumbsUp size={14} /></button>
                        <span className="text-[10px] text-stone-400 font-bold uppercase tracking-widest">Verified Academic Source</span>
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
          {isSearching && (
            <div className="flex justify-start">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="bg-stone-50 border border-stone-100 p-6 rounded-2xl rounded-tl-none w-full max-w-md"
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-5 h-5 border-2 border-[#5d4037] border-t-transparent rounded-full animate-spin"></div>
                  <span className="text-sm font-bold text-stone-700">Browsing academic databases...</span>
                </div>
                <div className="space-y-2">
                  <div className="h-1.5 bg-stone-200 rounded-full w-full animate-pulse"></div>
                  <div className="h-1.5 bg-stone-200 rounded-full w-3/4 animate-pulse [animation-delay:0.2s]"></div>
                  <div className="h-1.5 bg-stone-200 rounded-full w-1/2 animate-pulse [animation-delay:0.4s]"></div>
                </div>
                <div className="mt-4 flex flex-wrap gap-2">
                  <span className="text-[10px] bg-stone-200 text-stone-600 px-2 py-0.5 rounded-full font-bold">Scraping: Google Scholar</span>
                  <span className="text-[10px] bg-stone-200 text-stone-600 px-2 py-0.5 rounded-full font-bold">Analyzing: JSTOR</span>
                  <span className="text-[10px] bg-stone-200 text-stone-600 px-2 py-0.5 rounded-full font-bold">Query: {searchQuery}</span>
                </div>
              </motion.div>
            </div>
          )}
          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-stone-50 border border-stone-100 p-4 rounded-2xl rounded-tl-none flex gap-1.5">
                <span className="w-2 h-2 bg-stone-300 rounded-full animate-bounce"></span>
                <span className="w-2 h-2 bg-stone-300 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                <span className="w-2 h-2 bg-stone-300 rounded-full animate-bounce [animation-delay:0.4s]"></span>
              </div>
            </div>
          )}
        </div>

        <div className="p-4 bg-white border-t border-stone-100">
           <div className="mb-4 flex gap-2 overflow-x-auto no-scrollbar pb-1">
            {['Explain Newton\'s Laws', 'Integrate x^2 dx', 'Thesis on French Revolution', 'How do synapses work?'].map((suggestion) => (
              <button
                key={suggestion}
                onClick={() => setInput(suggestion)}
                className="whitespace-nowrap px-3 py-1.5 bg-stone-50 border border-stone-200 rounded-full text-xs font-semibold text-stone-600 hover:border-[#5d4037] hover:text-[#5d4037] transition-all"
              >
                {suggestion}
              </button>
            ))}
          </div>
          
          <div className="relative flex items-center group">
            <div className="absolute left-4 text-stone-400 group-focus-within:text-[#5d4037] transition-colors">
              <BrainCircuit size={20} />
            </div>
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Search Google Scholar, JSTOR, and OpenAI..."
              className="w-full bg-stone-50 border border-stone-200 rounded-2xl pl-12 pr-16 py-4 focus:ring-2 focus:ring-[#5d4037] focus:bg-white focus:border-transparent outline-none transition-all shadow-sm"
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || isTyping || isSearching}
              className="absolute right-2 p-3 bg-[#5d4037] text-white rounded-xl hover:bg-[#3e2723] disabled:opacity-50 transition-all shadow-lg active:scale-95"
            >
              <Send size={20} />
            </button>
          </div>
          <p className="text-[10px] text-center text-stone-400 mt-3 font-medium uppercase tracking-wider">
            Academic AI Mode • Synthesized from verified scholarly sources only.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AiTutor;
