import React from 'react';
import { motion } from 'framer-motion';
import { Star, Clock, Trophy, Sparkles, ShieldCheck, Users } from 'lucide-react';
import Hero3D from '../components/Hero3D';
import { useAuth } from '../hooks/useAuth';

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        staggerChildren: 0.1 
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  const stats = [
    { label: 'Points Earned', value: '0', icon: Star, color: 'bg-[#5d4037]' },
    { label: 'Learning Hours', value: '0.0', icon: Clock, color: 'bg-[#8d6e63]' },
    { label: 'Files Secured', value: '0', icon: ShieldCheck, color: 'bg-[#3e2723]' },
    { label: 'Peer Connections', value: '0', icon: Users, color: 'bg-stone-400' },
  ];

  return (
    <motion.div 
      initial="hidden"
      animate="visible"
      variants={containerVariants}
      className="space-y-8"
    >
      {/* Welcome Banner */}
      <motion.div 
        variants={itemVariants}
        className="brown-gradient p-8 rounded-3xl text-white shadow-xl relative overflow-hidden group"
      >
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-4">
            <div className="inline-block px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-xs font-bold tracking-widest uppercase mb-2">
              Student ID: {user?.id}
            </div>
            <h1 className="text-3xl md:text-5xl font-extrabold flex items-center gap-3">
              Welcome back, Scholar! <Sparkles className="text-yellow-400" />
            </h1>
            <p className="text-stone-200 text-lg max-w-md">
              Your AI tutor is ready to help you with today's challenges. You've completed 0% of your weekly goals!
            </p>
            <div className="flex gap-4">
              <button className="bg-white text-[#3e2723] px-6 py-2.5 rounded-xl font-bold shadow-lg hover:scale-105 transition-transform active:scale-95">
                Continue Learning
              </button>
              <button className="bg-stone-800/30 backdrop-blur-md text-white border border-white/20 px-6 py-2.5 rounded-xl font-bold shadow-lg hover:bg-stone-800/50 transition-all">
                View Schedule
              </button>
            </div>
          </div>
          <div className="hidden lg:block w-64 h-64">
            <Hero3D />
          </div>
        </div>
        
        {/* Animated Background Circles */}
        <div className="absolute -top-10 -right-10 w-64 h-64 bg-white/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-[#8d6e63]/20 rounded-full blur-3xl"></div>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <motion.div 
            key={stat.label}
            variants={itemVariants}
            className="bg-white p-6 rounded-2xl shadow-sm border border-stone-200 hover:shadow-md transition-shadow group cursor-default"
          >
            <div className={`w-12 h-12 ${stat.color} rounded-xl flex items-center justify-center text-white mb-4 group-hover:scale-110 transition-transform shadow-md`}>
              <stat.icon size={24} />
            </div>
            <p className="text-stone-500 text-sm font-medium">{stat.label}</p>
            <p className="text-3xl font-bold text-stone-800">{stat.value}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Upcoming Tasks */}
        <motion.div 
          variants={itemVariants}
          className="lg:col-span-2 bg-white rounded-3xl p-6 shadow-sm border border-stone-200"
        >
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-stone-800">Learning Path</h3>
            <button className="text-sm font-semibold text-[#5d4037] hover:underline">View all</button>
          </div>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center p-4 rounded-2xl hover:bg-stone-50 transition-colors border border-transparent hover:border-stone-100 group">
                <div className="w-12 h-12 bg-stone-100 rounded-full flex items-center justify-center font-bold text-stone-500 group-hover:bg-[#5d4037] group-hover:text-white transition-colors">
                  {i}
                </div>
                <div className="ml-4 flex-1">
                  <h4 className="font-bold text-stone-800">Introduction to Advanced Quantum Theory</h4>
                  <p className="text-sm text-stone-500">Duration: 45 mins • Due tomorrow</p>
                </div>
                <div className="h-2 w-24 bg-stone-100 rounded-full overflow-hidden">
                  <div className="h-full bg-[#5d4037]" style={{ width: `${i * 30}%` }}></div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Activity Summary */}
        <motion.div 
          variants={itemVariants}
          className="bg-white rounded-3xl p-6 shadow-sm border border-stone-200 flex flex-col items-center justify-center text-center"
        >
          <div className="w-20 h-20 bg-stone-100 text-stone-300 rounded-full flex items-center justify-center mb-4">
            <Trophy size={40} />
          </div>
          <h3 className="text-xl font-bold text-stone-800 mb-2">Weekly Goal</h3>
          <p className="text-stone-500 text-sm mb-6">You have spent 0 hours studying this week. Start your first session to see progress!</p>
          <button className="bg-stone-100 text-stone-400 px-6 py-2 rounded-xl font-bold cursor-not-allowed w-full">Reward Locked</button>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default Dashboard;
