import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Calculator as CalcIcon, Binary, FunctionSquare, Zap, RotateCcw, Equal } from 'lucide-react';
import * as math from 'mathjs';
import toast from 'react-hot-toast';

const Tools: React.FC = () => {
  const [calcInput, setCalcInput] = useState('');
  const [calcResult, setCalcResult] = useState('');
  const [solverInput, setSolverInput] = useState('');
  const [solverResult, setSolverResult] = useState<any>(null);

  const handleCalcClick = (val: string) => {
    if (val === '=') {
      try {
        setCalcResult(math.evaluate(calcInput).toString());
      } catch (err) {
        toast.error('Invalid Expression');
      }
    } else if (val === 'C') {
      setCalcInput('');
      setCalcResult('');
    } else {
      setCalcInput(prev => prev + val);
    }
  };

  const solveEquation = () => {
    try {
      // Mock math solver logic - in real app, use mathjs algebra features
      const result = math.simplify(solverInput).toString();
      setSolverResult(result);
      toast.success('Solved!');
    } catch (err) {
      toast.error('Could not solve equation');
    }
  };

  const calcButtons = [
    '7', '8', '9', '/',
    '4', '5', '6', '*',
    '1', '2', '3', '-',
    '0', '.', '=', '+',
    'C', '(', ')', '^'
  ];

  return (
    <div className="space-y-8 max-w-6xl mx-auto pb-12">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 bg-[#5d4037] rounded-2xl flex items-center justify-center text-white">
          <Binary size={28} />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-stone-800">Student Tools</h1>
          <p className="text-stone-500">Essential utilities for your academic journey.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Advanced Calculator */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white rounded-3xl p-6 shadow-sm border border-stone-200"
        >
          <div className="flex items-center gap-2 mb-6 text-stone-800">
            <CalcIcon size={24} />
            <h2 className="text-xl font-bold">Scientific Calculator</h2>
          </div>
          
          <div className="bg-stone-900 rounded-2xl p-6 mb-6 shadow-inner text-right min-h-[120px] flex flex-col justify-end">
            <div className="text-stone-500 text-sm font-mono mb-1 truncate h-5">{calcInput}</div>
            <div className="text-white text-4xl font-bold font-mono truncate">{calcResult || '0'}</div>
          </div>

          <div className="grid grid-cols-4 gap-3">
            {calcButtons.map(btn => (
              <button
                key={btn}
                onClick={() => handleCalcClick(btn)}
                className={`py-4 rounded-xl font-bold text-lg transition-all active:scale-95 ${
                  btn === '=' 
                    ? 'bg-[#5d4037] text-white col-span-1 shadow-md hover:bg-[#3e2723]' 
                    : btn === 'C'
                    ? 'bg-red-100 text-red-600 hover:bg-red-200'
                    : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                }`}
              >
                {btn}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Math Solver */}
        <div className="space-y-8">
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-white rounded-3xl p-6 shadow-sm border border-stone-200"
          >
            <div className="flex items-center gap-2 mb-6 text-stone-800">
              <FunctionSquare size={24} />
              <h2 className="text-xl font-bold">Smart Math Solver</h2>
            </div>
            
            <p className="text-sm text-stone-500 mb-4">Enter an algebraic expression or equation to simplify or solve.</p>
            
            <div className="space-y-4">
              <div className="relative">
                <input 
                  type="text" 
                  value={solverInput}
                  onChange={(e) => setSolverInput(e.target.value)}
                  placeholder="e.g. 2x + 5x + 10" 
                  className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-6 py-4 outline-none focus:ring-2 focus:ring-[#5d4037] font-mono text-lg"
                />
                <button 
                  onClick={solveEquation}
                  className="absolute right-2 top-2 bottom-2 bg-[#5d4037] text-white px-6 rounded-xl font-bold flex items-center gap-2 hover:bg-[#3e2723] transition-colors"
                >
                  <Zap size={18} /> Solve
                </button>
              </div>

              {solverResult && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-green-50 border border-green-100 p-6 rounded-2xl"
                >
                  <p className="text-xs text-green-600 font-bold uppercase tracking-wider mb-2">Simplified Result</p>
                  <div className="flex items-center gap-3 text-2xl font-bold text-stone-800 font-mono">
                    <Equal className="text-green-500" /> {solverResult}
                  </div>
                </motion.div>
              )}
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-[#5d4037] text-white rounded-3xl p-8 relative overflow-hidden"
          >
            <div className="relative z-10">
              <h3 className="text-xl font-bold mb-2">Unit Converter</h3>
              <p className="text-stone-300 text-sm mb-6">Need to convert measurements? This feature is coming soon to your toolkit!</p>
              <div className="flex gap-4">
                <div className="bg-white/10 p-3 rounded-xl border border-white/10 flex-1 text-center opacity-50">Length</div>
                <div className="bg-white/10 p-3 rounded-xl border border-white/10 flex-1 text-center opacity-50">Weight</div>
                <div className="bg-white/10 p-3 rounded-xl border border-white/10 flex-1 text-center opacity-50">Temp</div>
              </div>
            </div>
            <RotateCcw className="absolute -right-10 -bottom-10 w-48 h-48 text-white/5 rotate-12" />
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Tools;
