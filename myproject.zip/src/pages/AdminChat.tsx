import React, { useState, useEffect, useRef } from 'react';
import { Search, Send, Shield, User, Circle, Info, Paperclip, Mail } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

const AdminChat: React.FC = () => {
  const { user, users, messages, sendMessage } = useAuth();
  const [activeStudentId, setActiveStudentId] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, activeStudentId]);

  // Only students show up in admin's contact list
  const students = users.filter(u => u.role === 'student');
  const activeStudent = users.find(u => u.id === activeStudentId);

  const currentChatMessages = messages.filter(m => 
    (m.senderId === user?.id && m.receiverId === activeStudentId) ||
    (m.senderId === activeStudentId && m.receiverId === user?.id)
  );

  const handleSendMessage = () => {
    if (!message.trim() || !activeStudentId) return;
    
    // Admins send messages as admin messages (isAdminMsg = true)
    sendMessage(activeStudentId, message, true);
    
    // Ensure the admin is in the student's contact list so they see the reply
    const allContacts = JSON.parse(localStorage.getItem('all_user_contacts') || '{}');
    if (!allContacts[activeStudentId]) allContacts[activeStudentId] = [];
    if (!allContacts[activeStudentId].includes(user?.id)) {
      allContacts[activeStudentId].push(user?.id);
      localStorage.setItem('all_user_contacts', JSON.stringify(allContacts));
    }
    
    setMessage('');
    toast.success('Admin notification dispatched');
  };

  return (
    <div className="h-[calc(100vh-10rem)] bg-white rounded-3xl shadow-sm border border-stone-200 overflow-hidden flex flex-col md:flex-row">
      {/* Student List */}
      <div className={`w-full md:w-80 border-r border-stone-100 flex flex-col bg-stone-900 text-white ${activeStudentId ? 'hidden md:flex' : 'flex'}`}>
        <div className="p-6 border-b border-stone-800 space-y-4">
          <div className="flex items-center gap-3">
            <Shield className="text-stone-400" size={24} />
            <h2 className="font-bold text-lg tracking-tight">Admin Console</h2>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-500" size={16} />
            <input 
              type="text" 
              placeholder="Filter students..." 
              className="w-full pl-9 pr-4 py-2 bg-stone-800 border border-stone-700 rounded-xl focus:ring-1 focus:ring-stone-500 outline-none text-sm text-stone-100"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {students.map((student) => (
            <button
              key={student.id}
              onClick={() => setActiveStudentId(student.id)}
              className={`w-full p-4 flex items-center gap-4 hover:bg-stone-800 transition-all border-l-4 ${
                activeStudentId === student.id ? 'border-stone-100 bg-stone-800' : 'border-transparent'
              }`}
            >
              <div className="w-10 h-10 bg-stone-700 rounded-lg flex items-center justify-center font-bold text-stone-300">
                {student.username.charAt(0).toUpperCase()}
              </div>
              <div className="flex-1 text-left overflow-hidden">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-stone-200 truncate">{student.username}</h4>
                  <div className="w-2 h-2 rounded-full bg-green-500"></div>
                </div>
                <p className="text-[10px] text-stone-500 truncate font-mono">{student.id}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Admin Message Area */}
      <div className={`flex-1 flex flex-col bg-stone-50 ${!activeStudentId ? 'hidden md:flex' : 'flex'}`}>
        {!activeStudentId ? (
          <div className="flex-1 flex flex-col items-center justify-center text-stone-400 p-8 text-center bg-white">
            <div className="w-20 h-20 bg-stone-50 rounded-full flex items-center justify-center mb-4">
              <Mail size={40} className="opacity-20" />
            </div>
            <h3 className="text-xl font-bold text-stone-800">Support Terminal</h3>
            <p className="max-w-xs mt-2 text-sm">Select a student from the registry to initiate academic support or broadcast administrative notices.</p>
          </div>
        ) : (
          <>
            {/* Header */}
            <div className="p-4 border-b border-stone-200 flex items-center justify-between bg-white shadow-sm z-10">
              <div className="flex items-center gap-3">
                <button onClick={() => setActiveStudentId(null)} className="md:hidden p-2 -ml-2 text-stone-500">
                  <Info className="rotate-180" size={20} />
                </button>
                <div className="w-10 h-10 bg-stone-100 rounded-lg flex items-center justify-center font-bold text-stone-800 border border-stone-200">
                  {activeStudent?.username.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h3 className="font-bold text-stone-800 leading-none mb-1">{activeStudent?.username}</h3>
                  <p className="text-[10px] text-stone-500 font-bold flex items-center gap-1 uppercase tracking-widest">
                    <Circle size={6} fill="#22c55e" className="text-green-500" /> Authorized Connection
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="hidden lg:flex items-center gap-2 bg-stone-100 px-3 py-1 rounded-full text-[10px] font-bold text-stone-500">
                  <User size={12} /> ID: {activeStudent?.id}
                </div>
                <button className="p-2 text-stone-400 hover:text-stone-800 transition-colors"><Info size={20} /></button>
              </div>
            </div>

            {/* Admin Chat Log */}
            <div 
              ref={scrollRef}
              className="flex-1 overflow-y-auto p-6 space-y-4"
            >
              {currentChatMessages.map((msg) => {
                const isMe = msg.senderId === user?.id;
                return (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    key={msg.id} 
                    className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`max-w-[85%] md:max-w-[70%] shadow-sm p-4 rounded-2xl ${
                      isMe 
                        ? 'bg-stone-800 text-white rounded-tr-none' 
                        : 'bg-white text-stone-800 rounded-tl-none border border-stone-200'
                    }`}>
                      <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                      <p className={`text-[9px] mt-2 font-bold ${isMe ? 'text-stone-400' : 'text-stone-500'} text-right uppercase`}>
                        {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </motion.div>
                );
              })}
            </div>

            {/* Input */}
            <div className="p-4 bg-white border-t border-stone-200">
              <div className="flex items-center gap-3">
                <button className="p-2 text-stone-400 hover:text-stone-600 rounded-lg transition-colors">
                  <Paperclip size={20} />
                </button>
                <input 
                  type="text" 
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder="Type an official response..." 
                  className="flex-1 bg-stone-50 border border-stone-200 rounded-xl px-4 py-3 focus:ring-1 focus:ring-stone-800 outline-none text-sm transition-all"
                />
                <button 
                  onClick={handleSendMessage}
                  disabled={!message.trim()}
                  className="p-3 bg-stone-800 text-white rounded-xl hover:bg-black transition-all disabled:opacity-50"
                >
                  <Send size={20} />
                </button>
              </div>
              <div className="flex justify-center mt-2">
                <span className="text-[9px] text-stone-400 font-extrabold uppercase tracking-widest">Signed as EDU-VAULT Administrator</span>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default AdminChat;
