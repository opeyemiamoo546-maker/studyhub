import React, { useState, useEffect, useRef } from 'react';
import { Search, Send, Paperclip, Phone, Video, Info, Circle, UserPlus, User as UserIcon, Shield } from 'lucide-react';
import toast from 'react-hot-toast';
import { useAuth } from '../hooks/useAuth';
import { motion, AnimatePresence } from 'framer-motion';

const PeerChat: React.FC = () => {
  const { user, users, contacts, addContact, messages, sendMessage } = useAuth();
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const [newContactId, setNewContactId] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, activeChatId]);

  // Contacts include peers added by ID AND all admins (automatically)
  const activeContacts = users.filter(u => contacts.includes(u.id) || u.role === 'admin');
  const activeChatUser = users.find(u => u.id === activeChatId);

  // Filter messages for current chat
  const currentChatMessages = messages.filter(m => 
    (m.senderId === user?.id && m.receiverId === activeChatId) ||
    (m.senderId === activeChatId && m.receiverId === user?.id)
  );

  const handleAddContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (addContact(newContactId)) {
      toast.success('Peer added successfully!');
      setNewContactId('');
      setIsAdding(false);
    } else {
      toast.error('User not found or already added');
    }
  };

  const handleSendMessage = () => {
    if (!message.trim() || !activeChatId) return;
    sendMessage(activeChatId, message);
    setMessage('');
  };

  return (
    <div className="h-[calc(100vh-10rem)] bg-white rounded-3xl shadow-sm border border-stone-200 overflow-hidden flex flex-col md:flex-row">
      {/* Sidebar - Contacts */}
      <div className={`w-full md:w-80 border-r border-stone-100 flex flex-col bg-stone-50/50 ${activeChatId ? 'hidden md:flex' : 'flex'}`}>
        <div className="p-4 border-b border-stone-100 space-y-4">
          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <h2 className="font-bold text-stone-800">Direct Messages</h2>
              <button 
                onClick={() => setIsAdding(!isAdding)}
                className="p-2 hover:bg-stone-200 rounded-lg text-[#5d4037] transition-colors"
                title="Add Peer by ID"
              >
                <UserPlus size={20} />
              </button>
            </div>
            <div className="px-3 py-1.5 bg-[#efebe9] rounded-lg border border-stone-200">
              <p className="text-[10px] text-stone-500 font-bold uppercase tracking-wider mb-0.5">Your Sharing ID</p>
              <p className="text-xs font-mono font-black text-[#5d4037] flex items-center justify-between">
                {user?.id}
                <button onClick={() => {
                  navigator.clipboard.writeText(user?.id || '');
                  toast.success('ID Copied!');
                }} className="hover:text-stone-800 transition-colors">
                  <span className="text-[10px] underline">COPY</span>
                </button>
              </p>
            </div>
          </div>

          <AnimatePresence>
            {isAdding && (
              <motion.form 
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                onSubmit={handleAddContact}
                className="space-y-2 overflow-hidden pt-2"
              >
                <div className="bg-white p-3 rounded-xl border border-stone-200 shadow-sm">
                   <p className="text-[10px] font-bold text-stone-400 mb-2">ENTER PEER ID (e.g. STU-1234)</p>
                   <input 
                    type="text" 
                    value={newContactId}
                    onChange={(e) => setNewContactId(e.target.value)}
                    placeholder="STU-XXXX" 
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#5d4037] font-mono"
                  />
                  <button type="submit" className="w-full brown-btn py-2 text-xs mt-2 uppercase tracking-widest font-bold">Find & Connect</button>
                </div>
              </motion.form>
            )}
          </AnimatePresence>

          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" size={16} />
            <input 
              type="text" 
              placeholder="Search peers..." 
              className="w-full pl-9 pr-4 py-2 bg-white border border-stone-200 rounded-xl focus:ring-2 focus:ring-[#5d4037] outline-none text-sm"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {activeContacts.length === 0 ? (
            <div className="p-8 text-center">
              <div className="w-16 h-16 bg-stone-100 rounded-full flex items-center justify-center mx-auto mb-4 text-stone-300">
                <UserIcon size={32} />
              </div>
              <p className="text-sm font-bold text-stone-800">No Peers Found</p>
              <p className="text-xs text-stone-500 mt-1">Connect with classmates using their unique User ID.</p>
            </div>
          ) : (
            <div className="space-y-1">
              {activeContacts.map((contact) => (
                <button
                  key={contact.id}
                  onClick={() => setActiveChatId(contact.id)}
                  className={`w-full p-4 flex items-center gap-4 hover:bg-white transition-all border-l-4 ${
                    activeChatId === contact.id ? 'border-[#5d4037] bg-white' : 'border-transparent'
                  } ${contact.role === 'admin' ? 'bg-amber-50/30' : ''}`}
                >
                  <div className="relative">
                    <div className={`w-12 h-12 ${contact.role === 'admin' ? 'bg-stone-800' : 'bg-stone-200'} rounded-full flex items-center justify-center font-bold ${contact.role === 'admin' ? 'text-white' : 'text-stone-600'}`}>
                      {contact.role === 'admin' ? <Shield size={20} /> : contact.username.charAt(0).toUpperCase()}
                    </div>
                    <div className="absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white bg-green-500"></div>
                  </div>
                  <div className="flex-1 text-left overflow-hidden">
                    <div className="flex items-center justify-between">
                      <h4 className={`font-bold truncate ${contact.role === 'admin' ? 'text-[#5d4037]' : 'text-stone-800'}`}>
                        {contact.username} {contact.role === 'admin' && '✓'}
                      </h4>
                      <span className={`text-[10px] font-bold uppercase ${contact.role === 'admin' ? 'text-amber-600' : 'text-stone-400'}`}>
                        {contact.role}
                      </span>
                    </div>
                    <p className="text-xs text-stone-500 truncate font-mono">{contact.id}</p>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className={`flex-1 flex flex-col bg-white ${!activeChatId ? 'hidden md:flex' : 'flex'}`}>
        {!activeChatId ? (
          <div className="flex-1 flex flex-col items-center justify-center text-stone-400 p-8 text-center">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="space-y-6"
            >
              <div className="w-24 h-24 bg-stone-50 rounded-3xl flex items-center justify-center mx-auto shadow-sm">
                <Send size={48} className="text-[#5d4037] opacity-20" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-stone-800">Secure Messenger</h3>
                <p className="max-w-xs mt-2 text-stone-500">End-to-end simulated encryption. Select a contact to resume your conversation.</p>
              </div>
            </motion.div>
          </div>
        ) : (
          <>
            {/* Chat Header */}
            <div className="p-4 border-b border-stone-100 flex items-center justify-between bg-white/50 backdrop-blur-md sticky top-0 z-10">
              <div className="flex items-center gap-3">
                <button onClick={() => setActiveChatId(null)} className="md:hidden p-2 -ml-2 text-stone-500">
                  <Info className="rotate-180" size={20} />
                </button>
                <div className={`w-10 h-10 ${activeChatUser?.role === 'admin' ? 'bg-stone-800 text-white' : 'bg-stone-100 text-stone-600'} rounded-full flex items-center justify-center font-bold`}>
                  {activeChatUser?.role === 'admin' ? <Shield size={18} /> : activeChatUser?.username.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h3 className="font-bold text-stone-800 leading-none mb-1">{activeChatUser?.username}</h3>
                  <p className="text-[10px] text-green-600 font-extrabold flex items-center gap-1 uppercase tracking-tighter">
                    <Circle size={6} fill="currentColor" /> Active Session
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button className="p-2 text-stone-500 hover:bg-stone-100 rounded-lg transition-colors"><Phone size={18} /></button>
                <button className="p-2 text-stone-500 hover:bg-stone-100 rounded-lg transition-colors"><Video size={18} /></button>
                <button className="p-2 text-stone-500 hover:bg-stone-100 rounded-lg transition-colors"><Info size={18} /></button>
              </div>
            </div>

            {/* Messages */}
            <div 
              ref={scrollRef}
              className="flex-1 overflow-y-auto p-6 space-y-4 bg-stone-50/30"
            >
              {currentChatMessages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center opacity-30 grayscale scale-75">
                   <Send size={48} />
                   <p className="mt-4 font-bold uppercase tracking-widest text-xs">No Messages Yet</p>
                </div>
              ) : (
                currentChatMessages.map((msg) => {
                  const isMe = msg.senderId === user?.id;
                  return (
                    <motion.div 
                      initial={{ opacity: 0, x: isMe ? 20 : -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      key={msg.id} 
                      className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`max-w-[85%] md:max-w-[70%] shadow-sm p-4 rounded-2xl ${
                        isMe 
                          ? 'bg-[#5d4037] text-white rounded-tr-none' 
                          : msg.isAdminMsg 
                            ? 'bg-stone-800 text-white rounded-tl-none border border-stone-700'
                            : 'bg-white text-stone-800 rounded-tl-none border border-stone-100'
                      }`}>
                        {msg.isAdminMsg && !isMe && (
                          <div className="flex items-center gap-1.5 mb-1.5 opacity-70">
                            <Shield size={12} className="text-stone-300" />
                            <span className="text-[9px] font-extrabold uppercase tracking-widest text-stone-300">ADMIN MESSAGE</span>
                          </div>
                        )}
                        <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                        <p className={`text-[9px] mt-2 font-bold ${isMe || msg.isAdminMsg ? 'text-stone-300' : 'text-stone-400'} text-right uppercase`}>
                          {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                    </motion.div>
                  );
                })
              )}
            </div>

            {/* Input */}
            <div className="p-4 bg-white border-t border-stone-100 shadow-[0_-4px_10px_rgba(0,0,0,0.02)]">
              <div className="flex items-center gap-3">
                <button className="p-2 text-stone-400 hover:text-stone-600 hover:bg-stone-50 rounded-lg transition-all">
                  <Paperclip size={20} />
                </button>
                <input 
                  type="text" 
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder="Draft a message..." 
                  className="flex-1 bg-stone-50 border border-stone-100 rounded-xl px-4 py-3 focus:ring-2 focus:ring-[#5d4037] focus:bg-white outline-none text-sm transition-all"
                />
                <button 
                  onClick={handleSendMessage}
                  disabled={!message.trim()}
                  className="p-3 bg-[#5d4037] text-white rounded-xl hover:bg-[#3e2723] transition-all disabled:opacity-50 disabled:scale-95 shadow-lg shadow-stone-200"
                >
                  <Send size={20} />
                </button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default PeerChat;
