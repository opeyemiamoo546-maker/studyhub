import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShieldCheck, Lock, Unlock, FileText, Image as ImageIcon, File, Trash2, Plus, Search, Settings, RefreshCcw } from 'lucide-react';
import toast from 'react-hot-toast';
import { useAuth } from '../hooks/useAuth';

const FileVault: React.FC = () => {
  const { vaultPin, updateVaultPin, resetVaultPin } = useAuth();
  const [isLocked, setIsLocked] = useState(true);
  const [pin, setPin] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [newPin, setNewPin] = useState('');

  const [files] = useState([
    { name: 'Physics_Notes.pdf', type: 'pdf', size: '0 KB', date: new Date().toLocaleDateString() },
    { name: 'Project_Alpha_Draft.docx', type: 'doc', size: '0 KB', date: new Date().toLocaleDateString() },
  ]);

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin === vaultPin) {
      setIsLocked(false);
      toast.success('Vault Unlocked');
      setPin('');
    } else {
      toast.error('Incorrect PIN');
      setPin('');
    }
  };

  const handleForgotPin = () => {
    if (window.confirm('Reset vault PIN to default (0000)?')) {
      resetVaultPin();
      toast.success('PIN reset to 0000');
    }
  };

  const handleResetPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPin.length === 4 && /^\d+$/.test(newPin)) {
      updateVaultPin(newPin);
      toast.success('PIN Updated Successfully');
      setNewPin('');
      setShowSettings(false);
    } else {
      toast.error('PIN must be 4 digits');
    }
  };

  const getFileIcon = (type: string) => {
    switch (type) {
      case 'pdf': return <FileText className="text-red-500" />;
      case 'img': return <ImageIcon className="text-blue-500" />;
      default: return <File className="text-stone-400" />;
    }
  };

  if (isLocked) {
    return (
      <div className="flex flex-col items-center justify-center h-[70vh] p-4">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-white p-6 md:p-10 rounded-3xl shadow-2xl border border-stone-200 text-center max-w-sm w-full"
        >
          <div className="w-20 h-20 bg-stone-100 rounded-full flex items-center justify-center mx-auto mb-6 text-[#5d4037]">
            <Lock size={40} />
          </div>
          <h2 className="text-2xl font-bold text-stone-800 mb-2">Vault Locked</h2>
          <p className="text-stone-500 mb-8 text-sm">Enter your 4-digit PIN to access your private files.</p>
          
          <form onSubmit={handleUnlock} className="space-y-6">
            <input
              type="password"
              maxLength={4}
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              className="text-center text-3xl tracking-[1em] w-full py-4 bg-stone-50 border-2 border-stone-200 rounded-2xl focus:border-[#5d4037] outline-none transition-all font-bold"
              placeholder="••••"
              autoFocus
            />
            <button type="submit" className="brown-btn w-full py-4 flex items-center justify-center gap-2">
              <Unlock size={20} />
              Unlock Vault
            </button>
          </form>
          <button 
            onClick={handleForgotPin}
            className="mt-4 text-xs font-bold text-[#5d4037] hover:underline"
          >
            Forgot PIN? Reset to 0000
          </button>
          <p className="mt-4 text-[10px] text-stone-400 uppercase tracking-widest">Secure AES-256 Protected</p>
        </motion.div>
      </div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-8 p-4 md:p-0"
    >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-stone-800 flex items-center gap-2">
            <ShieldCheck className="text-green-600" /> Secure File Vault
          </h1>
          <p className="text-stone-500">Only you can see these documents.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative hidden md:block">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
            <input 
              type="text" 
              placeholder="Search files..." 
              className="pl-10 pr-4 py-2 bg-white border border-stone-200 rounded-xl focus:ring-2 focus:ring-[#5d4037] outline-none"
            />
          </div>
          <button 
            onClick={() => setShowSettings(!showSettings)}
            className="p-2 bg-stone-100 hover:bg-stone-200 rounded-xl text-stone-600 transition-colors"
            title="Vault Settings"
          >
            <Settings size={20} />
          </button>
          <button 
            onClick={() => setIsLocked(true)}
            className="p-2 bg-stone-100 hover:bg-stone-200 rounded-xl text-stone-600 transition-colors"
            title="Lock Vault"
          >
            <Lock size={20} />
          </button>
          <button className="brown-btn flex items-center gap-2">
            <Plus size={20} /> Upload
          </button>
        </div>
      </div>

      <AnimatePresence>
        {showSettings && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="bg-stone-50 p-6 rounded-3xl border border-stone-200 mb-6">
              <h3 className="font-bold text-stone-800 mb-4 flex items-center gap-2">
                <RefreshCcw size={18} /> Reset Vault PIN
              </h3>
              <form onSubmit={handleResetPin} className="flex flex-col md:flex-row gap-4 items-end">
                <div className="flex-1 w-full">
                  <label className="text-xs font-bold text-stone-500 uppercase block mb-1">New 4-Digit PIN</label>
                  <input 
                    type="password" 
                    maxLength={4}
                    value={newPin}
                    onChange={(e) => setNewPin(e.target.value)}
                    placeholder="••••"
                    className="w-full bg-white border border-stone-200 rounded-xl px-4 py-2 focus:ring-2 focus:ring-[#5d4037] outline-none font-bold tracking-widest"
                  />
                </div>
                <button type="submit" className="brown-btn w-full md:w-auto">Update PIN</button>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="bg-white rounded-3xl shadow-sm border border-stone-200 overflow-hidden overflow-x-auto">
        <table className="w-full text-left min-w-[600px]">
          <thead className="bg-stone-50 border-b border-stone-100">
            <tr>
              <th className="px-6 py-4 font-bold text-stone-600">Name</th>
              <th className="px-6 py-4 font-bold text-stone-600">Type</th>
              <th className="px-6 py-4 font-bold text-stone-600">Size</th>
              <th className="px-6 py-4 font-bold text-stone-600">Date Added</th>
              <th className="px-6 py-4 font-bold text-stone-600 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-100">
            <AnimatePresence>
              {files.map((file, idx) => (
                <motion.tr 
                  key={file.name}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className="hover:bg-stone-50 transition-colors group"
                >
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-stone-100 rounded-lg group-hover:bg-white transition-colors">
                        {getFileIcon(file.type)}
                      </div>
                      <span className="font-semibold text-stone-800">{file.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-stone-500 uppercase text-xs font-bold">{file.type}</td>
                  <td className="px-6 py-4 text-stone-500">{file.size}</td>
                  <td className="px-6 py-4 text-stone-500">{file.date}</td>
                  <td className="px-6 py-4 text-right">
                    <button className="text-stone-400 hover:text-red-500 transition-colors">
                      <Trash2 size={18} />
                    </button>
                  </td>
                </motion.tr>
              ))}
            </AnimatePresence>
          </tbody>
        </table>
      </div>
    </motion.div>
  );
};

export default FileVault;
