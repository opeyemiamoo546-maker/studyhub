import { useState, useEffect, createContext, useContext } from 'react';

interface User {
  id: string;
  username: string;
  email: string;
  role: 'admin' | 'student';
  createdAt: string;
}

interface Message {
  id: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  content: string;
  timestamp: string;
  isAdminMsg?: boolean;
}

interface AuthContextType {
  user: User | null;
  users: User[];
  vaultPin: string;
  contacts: string[]; 
  messages: Message[];
  login: (username: string) => void;
  logout: () => void;
  updateVaultPin: (newPin: string) => void;
  resetVaultPin: () => void;
  addContact: (userId: string) => boolean;
  sendMessage: (receiverId: string, content: string, isAdminMsg?: boolean) => void;
  isAdmin: boolean;
  refreshMessages: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [vaultPin, setVaultPin] = useState<string>('0000');
  const [contacts, setContacts] = useState<string[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);

  const refreshMessages = () => {
    const savedMsgs = localStorage.getItem('global_messages');
    if (savedMsgs) {
      setMessages(JSON.parse(savedMsgs));
    }
  };

  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    const savedUsers = localStorage.getItem('all_users');
    const savedPin = localStorage.getItem('vault_pin');
    const savedMsgs = localStorage.getItem('global_messages');
    
    if (savedUser) {
      const parsedUser = JSON.parse(savedUser);
      setUser(parsedUser);
      
      // Load user-specific contacts
      const allContacts = JSON.parse(localStorage.getItem('all_user_contacts') || '{}');
      setContacts(allContacts[parsedUser.id] || []);
    }
    
    if (savedPin) {
      setVaultPin(savedPin);
    } else {
      setVaultPin('0000');
      localStorage.setItem('vault_pin', '0000');
    }
    
    if (savedMsgs) {
      setMessages(JSON.parse(savedMsgs));
    }

    if (savedUsers) {
      setUsers(JSON.parse(savedUsers));
    } else {
      const initialUsers: User[] = [
        { id: 'ADM-101', username: 'admin', email: 'admin@eduvault.com', role: 'admin', createdAt: new Date().toISOString() },
      ];
      setUsers(initialUsers);
      localStorage.setItem('all_users', JSON.stringify(initialUsers));
    }

    // Polling for "real-time" updates in this demo environment
    const interval = setInterval(() => {
      refreshMessages();
      const allUsers = localStorage.getItem('all_users');
      if (allUsers) setUsers(JSON.parse(allUsers));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const login = (username: string) => {
    const allUsers = JSON.parse(localStorage.getItem('all_users') || '[]');
    const existingUser = allUsers.find((u: User) => u.username.toLowerCase() === username.toLowerCase());
    const isAdminRole = username.toLowerCase().includes('admin');
    
    let activeUser: User;

    if (existingUser) {
      activeUser = existingUser;
    } else {
      activeUser = { 
        id: `${isAdminRole ? 'ADM' : 'STU'}-${Math.floor(1000 + Math.random() * 8999)}`,
        username, 
        email: `${username.replace(/\s+/g, '_').toLowerCase()}@eduvault.edu`, 
        role: isAdminRole ? 'admin' : 'student',
        createdAt: new Date().toISOString()
      };
      const updated = [...allUsers, activeUser];
      setUsers(updated);
      localStorage.setItem('all_users', JSON.stringify(updated));
    }
    
    setUser(activeUser);
    localStorage.setItem('user', JSON.stringify(activeUser));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  const updateVaultPin = (newPin: string) => {
    setVaultPin(newPin);
    localStorage.setItem('vault_pin', newPin);
  };

  const resetVaultPin = () => {
    setVaultPin('0000');
    localStorage.setItem('vault_pin', '0000');
  };

  const addContact = (userId: string) => {
    if (!user) return false;
    const allUsers = JSON.parse(localStorage.getItem('all_users') || '[]');
    const targetUser = allUsers.find((u: User) => u.id === userId);
    
    if (targetUser && !contacts.includes(userId) && userId !== user.id) {
      const updated = [...contacts, userId];
      setContacts(updated);
      
      const allUserContacts = JSON.parse(localStorage.getItem('all_user_contacts') || '{}');
      allUserContacts[user.id] = updated;
      localStorage.setItem('all_user_contacts', JSON.stringify(allUserContacts));
      
      return true;
    }
    return false;
  };

  const sendMessage = (receiverId: string, content: string, isAdminMsg = false) => {
    if (!user) return;
    
    // Get latest messages from storage before appending
    const existingMsgs = JSON.parse(localStorage.getItem('global_messages') || '[]');
    
    const isActuallyAdminMsg = isAdminMsg || user.role === 'admin';
    
    const newMessage: Message = {
      id: Math.random().toString(36).substr(2, 9),
      senderId: user.id,
      senderName: user.username,
      receiverId,
      content,
      timestamp: new Date().toISOString(),
      isAdminMsg: isActuallyAdminMsg
    };

    const updated = [...existingMsgs, newMessage];
    setMessages(updated);
    localStorage.setItem('global_messages', JSON.stringify(updated));
    
    // Force a storage event for other tabs and a custom event for the current tab
    window.dispatchEvent(new CustomEvent('storage_messages_updated', { detail: newMessage }));
    
    // If it's an admin message, we might want to trigger a special broadcast
    if (isActuallyAdminMsg) {
      localStorage.setItem('last_admin_broadcast', JSON.stringify({
        ...newMessage,
        t: Date.now()
      }));
    }
  };

  const isAdmin = user?.role === 'admin';

  return (
    <AuthContext.Provider value={{ 
      user, users, vaultPin, contacts, messages, login, logout, updateVaultPin, resetVaultPin, addContact, sendMessage, isAdmin, refreshMessages
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
